package base;

import java.time.Duration;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	
private static final ThreadLocal<EdgeDriver> eDriver=new ThreadLocal<EdgeDriver>();

	public void setDriver() {
		eDriver.set(new EdgeDriver());
	}
	
	public EdgeDriver getDriver() {
		return eDriver.get();
	}
	
	@BeforeMethod
	public void preCondn() {
		setDriver();//driver is initialized
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	}
	@AfterMethod
	public void postCondn() {
		
		getDriver().close();
		
	}

}
